package com.xworkz.payment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.xworkz.payment.dto.PaymentDTO;
import com.xworkz.payment.service.PaymentService;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

@Controller
public class PaymentController {

	@Autowired
	private PaymentService paymentservice;
	public PaymentController() {
		System.out.println(this.getClass().getName()+" created");
	}
	@RequestMapping(value="/payment", method=RequestMethod.POST)
	public String savepayment(PaymentDTO dto,Model model) {
		System.out.println("dto from request\t"+dto);
		System.out.println("invoked payment \t");
		
		boolean valid = paymentservice.savePayment(dto);
		
		if(valid) {
			System.out.println("saved into db, returning success page");
			model.addAttribute("payment",dto);
			return "/success.jsp";
		}
		else {
			System.out.println("not saved n returning book ticket page");
			return "/index.jsp";
		}
		
		
	}
//	public void savPayment(PaymentDTO dto)
//	{
//		paymentservice.savePayment(dto);
//	}
}

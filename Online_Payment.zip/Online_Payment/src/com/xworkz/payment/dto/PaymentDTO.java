package com.xworkz.payment.dto;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Online_Payment")
public class PaymentDTO implements Serializable {
	@GenericGenerator(name="payment", strategy="increment")
	@GeneratedValue(generator="payment")
	@Id
	private Long id;
	private String name;
	private String exam;
	private String code;
	private String DateofExam;
	private String payment;
	private long phone;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getExam() {
		return exam;
	}

	public void setExam(String exam) {
		this.exam = exam;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDateofExam() {
		return DateofExam;
	}

	public void setDateofExam(String dateofExam) {
		DateofExam = dateofExam;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "PaymentDTO [name=" + name + ", exam=" + exam + ", code=" + code + ", DateofExam=" + DateofExam
				+ ", payment=" + payment + ", phone=" + phone + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}

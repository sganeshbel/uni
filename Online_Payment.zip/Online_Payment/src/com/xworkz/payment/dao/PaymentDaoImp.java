package com.xworkz.payment.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.xworkz.payment.dto.PaymentDTO;
@Component
public class PaymentDaoImp implements PaymentDAO {
	@Autowired
//	@Qualifier("anotherFactoy")
	private SessionFactory sessionFactory;

	public PaymentDaoImp() {
		System.out.println(this.getClass().getName()+" created");
	}
	
	@Override
	public void savePayment(PaymentDTO dto) {
	System.out.println("save method inside paymentdao implement");
		Session session = sessionFactory.openSession();
		
		//Transaction tx = session.beginTransaction();
		session.beginTransaction();
		try {
			Serializable returnTypeOfsave=session.save(dto);
			System.out.println("saved obj with serial\t"+returnTypeOfsave);
			session.getTransaction().commit();
			//tx.commit();
		} catch (Exception e) {
			System.err.println(e);
			session.getTransaction().rollback();
		}
		 finally {
			 session.close();
		 }

	}

}

package com.xworkz.payment.dao;

import com.xworkz.payment.dto.PaymentDTO;

public interface PaymentDAO {
public void savePayment(PaymentDTO dto);
}

package com.xworkz.payment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xworkz.payment.dao.PaymentDAO;
import com.xworkz.payment.dto.PaymentDTO;
@Component
public class PaymentServiceImp implements PaymentService {
	@Autowired
	private PaymentDAO paymentDao;
	
	public PaymentServiceImp() {
	System.out.println(this.getClass().getName()+"created");
	}
	@Override
	public boolean savePayment(PaymentDTO dto)
	{
		System.out.println("invoke payment from service");
		
		
		boolean valid= false;
		
		if(dto!=null) {
			
			System.out.println("validating payment service in dto");
			
			if(dto.getName()!=null && !dto.getName().isEmpty()) {
				System.out.println("valid name for payment");
				 if(dto.getExam()!=null && !dto.getExam().isEmpty()) {
					 System.out.println("valid exam for payment");
					 valid=true;
				      }
				 
				 else {
					 System.out.println("invalid exam for payment");
				    }
			}
			
			
			else {
				System.out.println("invalid name for payment");
			}
			
			
		}
		if(valid) {
			System.out.println("data for payment is vali,passing this to dao");
			paymentDao.savePayment(dto);
			
		}
		else {
			System.out.println("data for payment is invalid");
		}
		//paymentDao.savePayment(dto);
		return valid;
		
	}

}

package com.xworkz.payment.service;

import com.xworkz.payment.dto.PaymentDTO;

public interface PaymentService {
	public boolean savePayment(PaymentDTO dto);
}

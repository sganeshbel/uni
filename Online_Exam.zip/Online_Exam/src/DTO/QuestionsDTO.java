package DTO;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="questions_table")
public class QuestionsDTO implements Serializable {
	@Id
	@GenericGenerator(name="qst_auto_increment", strategy="increment")
	@GeneratedValue(generator="qst_auto_increment")
	@Column(name="question_no")
private int question_no;
	
	@Column(name="question_name")
private String question_name;
	
	@Column(name="option_a")
private String option_a;
	
	@Column(name="option_b")
private String option_b;
	
	@Column(name="option_c")
private String option_c;
	
	@Column(name="option_d")
private String option_d;
	
	@Column(name="answer")
private String answer;

public QuestionsDTO() {
	// TODO Auto-generated constructor stub
}

public int getQuestion_no() {
	return question_no;
}

public void setQuestion_no(int question_no) {
	this.question_no = question_no;
}

public String getQuestion_name() {
	return question_name;
}

public void setQuestion_name(String question_name) {
	this.question_name = question_name;
}

public String getOption_a() {
	return option_a;
}

public void setOption_a(String option_a) {
	this.option_a = option_a;
}

public String getOption_b() {
	return option_b;
}

public void setOption_b(String option_b) {
	this.option_b = option_b;
}

public String getOption_c() {
	return option_c;
}

public void setOption_c(String option_c) {
	this.option_c = option_c;
}

public String getOption_d() {
	return option_d;
}

public void setOption_d(String option_d) {
	this.option_d = option_d;
}

public String getAnswer() {
	return answer;
}

public void setAnswer(String answer) {
	this.answer = answer;
}

@Override
public String toString() {
	return "QuestionsDTO [question_no=" + question_no + ", question_name=" + question_name + ", option_a=" + option_a
			+ ", option_b=" + option_b + ", option_c=" + option_c + ", option_d=" + option_d + ", answer=" + answer
			+ "]";
}
}

package Mainclass;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;

import com.sun.xml.internal.messaging.saaj.packaging.mime.util.QEncoderStream;

import DAO.QuestionsDAO;
import DTO.RegisterDTO;
import util.Hibernateutil;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter out = response.getWriter();
	out.println("login servlet");
	String email = request.getParameter("email");
	String password = request.getParameter("password");
	QuestionsDAO reg_obj = new QuestionsDAO();
	//RegisterDTO e1 = (RegisterDTO)reg_obj.CheckRegByEmailAndPwd(email, password);
	RegisterDTO dto = new RegisterDTO();
	//out.print(dto.getEmail()+"pass is :"+dto.getConfirm_password());
	Session session = Hibernateutil.getfactory().openSession();
	Query query1 = session.createQuery("select reg.name from RegisterDTO reg where reg.email='"+email+"' and reg.confirm_password='"+password+"'");
	String s = (String) query1.uniqueResult();
	if(s!=null) {
		response.sendRedirect("Take_test.jsp");
	} else 
		response.sendRedirect("LoginFail.jsp");
	System.out.println("email is "+s);
	out.print(email+":"+password);
	session.close();
	}

}

package Mainclass;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.QuestionsDAO;
import DTO.QuestionsDTO;
import DTO.RegisterDTO;

/**
 * Servlet implementation class ControllerClass
 */
@WebServlet("/ControllerClass")
public class ControllerClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter out = response.getWriter();
	RegisterDTO regdto = new RegisterDTO();
		String name = request.getParameter("reg_name");
		String email = request.getParameter("reg_email");
		String create_password = request.getParameter("reg_password");
		String confrim_pwd = request.getParameter("reg_confrim_password");
		int mobile = Integer.parseInt(request.getParameter("reg_mobile"));
		String gender = request.getParameter("reg_gender");
		String qualification = request.getParameter("qualification");
		out.println("Controllerclass");
		out.println(confrim_pwd);
		//insert these values into db
		
		QuestionsDAO regdao = new  QuestionsDAO();
		regdto.setName(name);
		regdto.setEmail(email);
		regdto.setCreate_password(create_password);
		regdto.setConfirm_password(confrim_pwd);
		regdto.setMobile(mobile);
		regdto.setGender(gender);
		regdto.setQualification(qualification);
		regdao.insertRegMethod(regdto);
	}

}

package Mainclass;

import java.util.List;

import DAO.QuestionsDAO;
import DTO.QuestionsDTO;

public class DisplayController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
QuestionsDTO dto = new QuestionsDTO();






QuestionsDAO dao= new QuestionsDAO();
List<QuestionsDTO> qst = dao.fetchAllQuestions();
for (QuestionsDTO questionsDTO : qst) {
	System.out.println(questionsDTO);
}
	}

}

package DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import DTO.QuestionsDTO;
import DTO.RegisterDTO;
import util.Hibernateutil;

public class QuestionsDAO {
	
	// method for fetch values
	public List<QuestionsDTO> fetchAllQuestions() {
		
	
Session session = Hibernateutil.getfactory().openSession();
Query query1 = session.createQuery("from QuestionsDTO");
List<QuestionsDTO> questions = query1.list();
return questions;
	}
	
	// method for insert values
	public void insertRegMethod(RegisterDTO regdto) {
		Session session = Hibernateutil.getfactory().openSession();
		Transaction tx = session.beginTransaction();
		session.save(regdto);
		tx.commit();
		session.close();	
	}
	
	//method to check register
	public RegisterDTO CheckRegByEmailAndPwd(String email,String password) {
		Session session = Hibernateutil.getfactory().openSession();
		Query query1 = session.createQuery("select reg.name from RegisterDTO reg where reg.email=:email and reg.create_password=:password");
		query1.setString("email", email);
		query1.setString("password", password);
		RegisterDTO s1= (RegisterDTO) query1.uniqueResult();
	    return s1;
	}

}

package com.xworkz;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SportsDAO {

	public void save(SportsDTO dto) {

		System.out.println(dto);
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(SportsDTO.class);
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		try {
			session.save(dto);
			tx.commit();
			System.out.println("saved into db");
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			factory.close();
		}

	}

	public SportsDTO getSports(int sportsId) {
		SportsDTO sports = new SportsDTO();
		sports.setId(123);
		sports.setName("cricket");
		sports.setPlace("bangalore");
		return sports;
	}
}
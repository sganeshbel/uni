package com.xworkz.tester;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xworkz.SportsDAO;
import com.xworkz.SportsDTO;

/**
 * Servlet implementation class test
 */
public class test extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public test() {
		super();
		System.out.println(this.getClass().getName());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		int SportsId = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String place = request.getParameter("place");
		SportsDAO dao =  new SportsDAO();
		SportsDTO dto = dao.getSports(SportsId);
	   dto.setId(SportsId);
		dto.setName(name);
		dto.setPlace(place);
		dao.save(dto);
		
		request.setAttribute("dto", dto);
		RequestDispatcher rd = request.getRequestDispatcher("details.jsp");
		rd.forward(request, response);
	}

}

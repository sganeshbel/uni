package DTO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="online_test_table")
public class TestDTO {
	@Id
	@GenericGenerator(name="register", strategy="increment")
	@GeneratedValue(generator="register")
	@Column(name="qno")
private int qno;
	
	@Column(name="question")	
private String question;

	@Column(name="option_a")
private String option_a;

	@Column(name="option_b")
private String option_b;

	@Column(name="option_c")
private String option_c;

	@Column(name="option_d")
private String option_d;

	@Column(name="answer")
private String answer;
public TestDTO() {
	// TODO Auto-generated constructor stub
}
public int getQno() {
	return qno;
}
public void setQno(int qno) {
	this.qno = qno;
}
public String getQuestion() {
	return question;
}
public void setQuestion(String question) {
	this.question = question;
}
public String getOption_a() {
	return option_a;
}
public void setOption_a(String option_a) {
	this.option_a = option_a;
}
public String getOption_b() {
	return option_b;
}
public void setOption_b(String option_b) {
	this.option_b = option_b;
}
public String getOption_c() {
	return option_c;
}
public void setOption_c(String option_c) {
	this.option_c = option_c;
}
public String getOption_d() {
	return option_d;
}
public void setOption_d(String option_d) {
	this.option_d = option_d;
}
public String getAnswer() {
	return answer;
}
public void setAnswer(String answer) {
	this.answer = answer;
}
@Override
public String toString() {
	return "TestDTO [qno=" + qno + ", question=" + question + ", option_a=" + option_a + ", option_b=" + option_b
			+ ", option_c=" + option_c + ", option_d=" + option_d + ", answer=" + answer + "]";
}

}

package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.DisplayDAO;
import DTO.TestDTO;

/**
 * Servlet implementation class QuestionsServlet
 */
@WebServlet("/QuestionsServlet1")
public class QuestionsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuestionsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/** for (TestDTO testDTO : qn) {
//		System.out.println(testDTO);
//		//request.getSession().setAttribute("testdto", testDTO);
//	}
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter out = response.getWriter();

	DisplayDAO dao = new DisplayDAO();
	List<TestDTO> qn = dao.Display_questions_method();
	for (TestDTO testDTO : qn) {
//		System.out.println(testDTO);
		
	}
	request.setAttribute("questionslist", qn);
	RequestDispatcher rd = request.getRequestDispatcher("display_questions.jsp");
	//response.sendRedirect("index.jsp");
	rd.forward(request, response);
	}

}

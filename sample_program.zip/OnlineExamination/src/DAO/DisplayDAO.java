package DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import DTO.TestDTO;
import util.Hibernateutil;

public class DisplayDAO {

	public List<TestDTO> Display_questions_method() {
    Session session = Hibernateutil.getfactory().openSession();
    Query query1 = session.createQuery("from TestDTO");
    List<TestDTO> question = query1.list(); 
		
	return question;
	
		
	}
	
	
}
